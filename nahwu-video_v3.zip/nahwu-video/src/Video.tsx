import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadAmiri} from '@remotion/google-fonts/Amiri';
import {AUDIO_SECONDS, CLAUSES, SCENES} from './timing';
import * as LEG from './timingLegacy';
import {FPS, SceneProvider, TOTAL_FRAMES, cs, sceneRange, sec} from './lib';
import {Background} from './components/Background';
import {Subtitle} from './components/Subtitle';
import {Foreground, GoldFrame, Grade, LightSweep} from './components/Ornament';
import {Hook, Era, Tugas, Harakat} from './scenes/Part1';
import {Ishabah, Kubu, Tumpuk, Peta} from './scenes/Part2';
import {Alfiyah, Konon, Wafat, Cta, Sources} from './scenes/Part3';

loadPoppins('normal', {weights: ['500', '600', '700', '800'], subsets: ['latin']});
loadAmiri('normal', {weights: ['400', '700'], subsets: ['arabic', 'latin']});

type SceneDef = {key: string; C: React.FC<{dur: number}>};
const ORDER: SceneDef[] = [
  {key: 'hook', C: Hook}, {key: 'era', C: Era}, {key: 'tugas', C: Tugas}, {key: 'harakat', C: Harakat},
  {key: 'ishabah', C: Ishabah}, {key: 'kubu', C: Kubu}, {key: 'tumpuk', C: Tumpuk}, {key: 'peta', C: Peta},
  {key: 'alfiyah', C: Alfiyah}, {key: 'konon', C: Konon}, {key: 'wafat', C: Wafat}, {key: 'cta', C: Cta},
];

/*
 * Penempatan cue SFX mengikuti penanda klausa (mis. "impact di awal klausa 22").
 * Berkas audio (voiceover.wav, pad.mp3, sfx/*.wav) TIDAK diubah sama sekali.
 * Timing klausa dikoreksi di v3 karena versi awal meleset hingga ±5 dtk dari suara asli (lihat README).
 * Set LEGACY_SFX_TIMING = true untuk mengembalikan frame cue SFX persis seperti versi awal.
 */
const LEGACY_SFX_TIMING = false;
const csx = (i: number) => sec((LEGACY_SFX_TIMING ? LEG.CLAUSES : CLAUSES)[i].s);
const sceneFromX = (key: string) => sec((LEGACY_SFX_TIMING ? LEG.SCENES : SCENES).find((x) => x.key === key)!.s);

/* ── Efek suara: [frame, berkas, volume] ── */
const S = (f: number, file: string, vol: number): [number, string, number] => [f, file, vol];
const sfx: [number, string, number][] = [
  S(0, 'scratch', 0.35), S(csx(1), 'impact', 0.85), S(csx(1) + 3, 'chime', 0.3),
  // era
  S(csx(3) - 20, 'riser', 0.3), S(csx(5), 'impact', 0.5),
  ...Array.from({length: 18}, (_, i) => S(csx(7) + i * 5, 'tick', 0.3)),
  // tugas
  S(csx(8) + 26, 'whoosh', 0.35), S(csx(9), 'chime', 0.4),
  // harakat
  S(csx(11) + 18, 'impact', 0.55), S(csx(11) + 18, 'chime', 0.45),
  ...Array.from({length: 6}, (_, i) => S(csx(13) + i * 6, 'tick', 0.45)),
  // ishabah
  S(csx(15) + 2, 'impact', 0.55), S(csx(16) + 6, 'whoosh', 0.3), S(csx(17), 'whoosh', 0.3), S(csx(19) + 20, 'chime', 0.4),
  // kubu
  S(csx(22) + 4, 'impact', 0.9), S(csx(24), 'whoosh', 0.3), S(csx(26), 'whoosh', 0.3), S(csx(28), 'riser', 0.3),
  // tumpuk
  ...Array.from({length: 10}, (_, i) => S(csx(31) + i * 9 + 12, 'tick', 0.5)), S(csx(33), 'impact', 0.5),
  // peta
  S(csx(34) + 14, 'whoosh', 0.35), S(csx(35), 'chime', 0.45),
  // alfiyah
  ...Array.from({length: 10}, (_, i) => S(csx(38) + i * 4, 'tick', 0.3)),
  S(csx(39), 'impact', 0.7), S(csx(40), 'whoosh', 0.4),
  ...Array.from({length: 6}, (_, i) => S(csx(40) + 8 + i * 4, 'tick', 0.3)),
  S(csx(42), 'impact', 0.8), S(csx(42), 'chime', 0.45),
  // konon
  S(csx(46), 'impact', 0.6), S(csx(47), 'riser', 0.25), S(csx(48), 'scratch', 0.5), S(csx(49), 'chime', 0.45), S(csx(50), 'impact', 0.7),
  // wafat
  S(csx(53), 'impact', 0.8), S(csx(54), 'whoosh', 0.3),
  // cta
  S(csx(56), 'chime', 0.5), S(csx(57), 'whoosh', 0.4),
];
// whoosh di tiap pergantian adegan
const sceneWhoosh: [number, string, number][] = ORDER.slice(1).map((s) => S(sceneFromX(s.key) - 4, 'whoosh', 0.3));

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const kon = sceneRange('konon');
  const warm = interpolate(frame, [cs(47), cs(47) + 36, kon.from + kon.dur - 10, kon.from + kon.dur + 10], [0, 0.9, 0.9, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const audioEnd = sec(AUDIO_SECONDS);
  const src = sceneRange('cta');
  const srcFrom = audioEnd;
  const bgmVol = (f: number) => interpolate(f, [0, 60, TOTAL_FRAMES - 70, TOTAL_FRAMES], [0, 0.09, 0.09, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <SceneProvider start={0}>
        <Background warm={warm} />
      </SceneProvider>

      <AbsoluteFill style={{transform: 'none'}}>
      {ORDER.map(({key, C: Scene}) => {
        const {from, dur} = sceneRange(key);
        return (
          <Sequence key={key} from={from} durationInFrames={dur}>
            <SceneProvider start={from}>
              <Scene dur={dur} />
            </SceneProvider>
          </Sequence>
        );
      })}
      <Sequence from={srcFrom} durationInFrames={TOTAL_FRAMES - srcFrom}>
        <SceneProvider start={srcFrom}>
          <Sources dur={TOTAL_FRAMES - srcFrom} />
        </SceneProvider>
      </Sequence>
      </AbsoluteFill>

      <SceneProvider start={0}>
        <Foreground />
        <Grade />
        <GoldFrame />
      </SceneProvider>

      <Subtitle />

      {/* audio */}
      <Audio src={staticFile('voiceover.wav')} volume={1} />
      <Audio src={staticFile('sfx/pad.mp3')} volume={bgmVol} />
      {[...sfx, ...sceneWhoosh, S(srcFrom - 2, 'whoosh', 0.3)].map(([f, file, vol], i) => (
        <Sequence key={i} from={Math.max(0, f)} durationInFrames={FPS * 3}>
          <Audio src={staticFile(`sfx/${file}.wav`)} volume={vol} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
