import React from 'react';
import {AbsoluteFill} from 'remotion';
import {C, H, W, useAnim} from '../lib';

/**
 * Latar serambi/ruang belajar sederhana: lengkung (arch), tiang, jendela berkas cahaya senja,
 * rak gulungan, dan lantai berkarpet. Murni SVG/CSS buatan kode (bukan gambar AI).
 * `tone`: 'dusk' (senja hangat) atau 'night' (lampu minyak).
 */
export const Serambi: React.FC<{tone?: 'dusk' | 'night'; opacity?: number; lamp?: boolean}> = ({tone = 'dusk', opacity = 1, lamp = false}) => {
  const {f} = useAnim();
  const warm = tone === 'dusk' ? 'rgba(255,196,110,' : 'rgba(255,170,80,';
  const flick = lamp ? 0.85 + 0.15 * Math.sin(f / 3) * Math.sin(f / 7) : 1;
  const shaft = 0.5 + 0.12 * Math.sin(f / 70);
  return (
    <AbsoluteFill style={{opacity, pointerEvents: 'none'}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="srWall" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#0a0f1d" />
            <stop offset="0.55" stopColor="#1a1612" />
            <stop offset="1" stopColor="#0b0a0a" />
          </linearGradient>
          <radialGradient id="srGlow" cx="50%" cy="38%" r="55%">
            <stop offset="0" stopColor={`${warm}0.55)`} />
            <stop offset="0.5" stopColor={`${warm}0.14)`} />
            <stop offset="1" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
          <linearGradient id="srShaft" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={`${warm}0.55)`} />
            <stop offset="1" stopColor={`${warm}0)`} />
          </linearGradient>
          <linearGradient id="srFloor" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#1d1710" />
            <stop offset="1" stopColor="#050405" />
          </linearGradient>
          <filter id="srBlur"><feGaussianBlur stdDeviation="18" /></filter>
        </defs>
        <rect width={W} height={H} fill="url(#srWall)" />
        <rect width={W} height={H} fill="url(#srGlow)" opacity={flick} />
        {/* lengkung besar (pointed arch) */}
        <path d={`M 90 1240 V 560 C 90 280 380 150 540 120 C 700 150 990 280 990 560 V 1240 H 880 V 580 C 880 380 700 290 540 262 C 380 290 200 380 200 580 V 1240 Z`} fill="#070a14" stroke={C.gold} strokeOpacity={0.28} strokeWidth={2} />
        {/* lengkung dalam + jendela berteralis */}
        <path d={`M 360 760 V 520 C 360 400 450 350 540 330 C 630 350 720 400 720 520 V 760 Z`} fill={`${warm}0.30)`} stroke={C.gold} strokeOpacity={0.5} strokeWidth={3} />
        {[0, 1, 2, 3].map((k) => <line key={k} x1={450 + k * 60} y1={340} x2={450 + k * 60} y2={760} stroke={C.gold} strokeOpacity={0.35} strokeWidth={2} />)}
        {[0, 1, 2].map((k) => <line key={k} x1={360} y1={470 + k * 100} x2={720} y2={470 + k * 100} stroke={C.gold} strokeOpacity={0.28} strokeWidth={2} />)}
        {/* berkas cahaya dari jendela */}
        <g filter="url(#srBlur)" opacity={shaft}>
          <polygon points="400,720 680,720 940,1500 140,1500" fill="url(#srShaft)" opacity={0.55} />
        </g>
        {/* tiang & kapital */}
        {[150, 930].map((cx, i) => (
          <g key={i}>
            <rect x={cx - 34} y={600} width={68} height={640} fill="#0b0d16" stroke={C.gold} strokeOpacity={0.16} />
            <path d={`M ${cx - 56} 600 H ${cx + 56} L ${cx + 40} 560 H ${cx - 40} Z`} fill="#101322" stroke={C.gold} strokeOpacity={0.3} />
          </g>
        ))}
        {/* rak gulungan di sisi */}
        {[0, 1, 2].map((r) =>
          [0, 1, 2].map((c) => (
            <rect key={`${r}${c}`} x={236 + c * 54} y={860 + r * 110} width={44} height={16} rx={8} fill="#c9b27a" opacity={0.22} />
          )),
        )}
        {/* lantai & karpet */}
        <rect x={0} y={1240} width={W} height={H - 1240} fill="url(#srFloor)" />
        <path d={`M 160 1300 H 920 L 1010 1760 H 70 Z`} fill="#2a1710" opacity={0.75} stroke={C.gold} strokeOpacity={0.25} />
        <path d={`M 250 1340 H 830 L 890 1700 H 190 Z`} fill="none" stroke={C.gold} strokeOpacity={0.3} strokeWidth={2} />
        {/* lampu gantung */}
        {lamp && (
          <g>
            <line x1={190} y1={0} x2={190} y2={520} stroke={C.gold} strokeOpacity={0.4} strokeWidth={3} />
            <circle cx={190} cy={540} r={70 * flick} fill={`${warm}0.28)`} filter="url(#srBlur)" />
            <circle cx={190} cy={540} r={16} fill={C.gold} opacity={0.9 * flick} />
          </g>
        )}
      </svg>
      {/* kabut/debu halus */}
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%, rgba(255,190,110,0.10), transparent 60%)', mixBlendMode: 'screen'}} />
    </AbsoluteFill>
  );
};
