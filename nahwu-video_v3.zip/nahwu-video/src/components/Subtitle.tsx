import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CHUNKS} from '../timing';
import {C, FPS, Latin} from '../lib';

/**
 * Subtitle per frasa pendek (maks. 4 kata / ±26 huruf, 2 baris), disinkronkan ke timing.ts v3
 * (segmen ucapan nyata di audio). Kata aktif disorot. Tidak tampil saat narator diam (jeda).
 */
const LEAD = 0.05; // tampil sedikit sebelum kata pertama
const TAIL = 0.14; // bertahan sebentar setelah kata terakhir

export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  // chunk terakhir yang sudah mulai; berhenti tampil bila sudah lewat TAIL
  let chunk = null as (typeof CHUNKS)[number] | null;
  for (const c of CHUNKS) {
    if (c.s - LEAD <= t) chunk = c;
    else break;
  }
  if (!chunk || t >= chunk.e + TAIL) return null;
  const enter = Math.min(1, (t - (chunk.s - LEAD)) / 0.1);
  const exit = Math.min(1, Math.max(0, (chunk.e + TAIL - t) / 0.1));
  const o = Math.min(enter, exit);
  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        bottom: 340,
        display: 'flex',
        justifyContent: 'center',
        flexWrap: 'wrap',
        gap: '6px 22px',
        opacity: o,
        transform: `translateY(${(1 - o) * 14}px)`,
        ...Latin,
        fontWeight: 800,
        fontSize: 70,
        lineHeight: 1.18,
        textAlign: 'center',
        textShadow: '0 4px 18px rgba(0,0,0,0.95), 0 0 3px rgba(0,0,0,1)',
      }}
    >
      <div style={{position: 'absolute', left: '50%', bottom: -26, width: 520 * o, height: 3, marginLeft: -260 * o, background: `linear-gradient(90deg, transparent, ${C.gold}, transparent)`, boxShadow: `0 0 14px ${C.gold}`}} />
      {chunk.words.map((w, i) => {
        const active = t >= w.s && t < w.e;
        return (
          <span
            key={i}
            style={{
              color: active ? '#ffd877' : '#fff',
              transform: `scale(${active ? 1.07 : 1}) translateY(${active ? -3 : 0}px)`,
              display: 'inline-block',
              textShadow: active ? `0 0 26px ${C.orange}, 0 4px 18px rgba(0,0,0,0.95)` : undefined,
            }}
          >
            {w.t}
          </span>
        );
      })}
    </div>
  );
};
