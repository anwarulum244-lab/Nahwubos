import React from 'react';
import {interpolate} from 'remotion';
import {C, Latin, useAnim} from '../lib';

type Pose = 'stand' | 'sit';
type Props = {
  x: number;
  y: number;
  scale?: number;
  /** dipertahankan demi kompatibilitas; bentuk siluet tidak memuat detail wajah */
  turban?: boolean;
  beard?: boolean;
  opacity?: number;
  label?: string;
  sub?: string;
  /** warna rim light (default emas) */
  rim?: string;
  flip?: boolean;
  pose?: Pose;
  /** tangan terangkat (gestur mengajar) untuk pose berdiri */
  gesture?: boolean;
  /** frame absolut: rim light masuk perlahan mulai di sini (kosong = langsung menyala) */
  rimAt?: number;
  /** frame absolut: rim light mulai memudar halus, selesai di rimUntil + 28 */
  rimUntil?: number;
};

const INK = '#03050b';

const hex2rgba = (hex: string, a: number) => {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${Math.max(0, Math.min(1, a))})`;
};

/**
 * Siluet hitam pekat TANPA detail wajah (tak ada mata/hidung/mulut), dengan rim light emas tipis.
 * Rim light bersifat statis di tepi siluet: masuk perlahan → bertahan → memudar. Tidak ada cahaya yang berlari.
 * Ilustrasi simbolis, bukan potret autentik.
 */
export const Silhouette: React.FC<Props> = ({
  x, y, scale = 1, opacity = 1, label, sub, rim = C.gold, flip, pose = 'stand', gesture = false, rimAt, rimUntil,
}) => {
  const {f} = useAnim();
  const rin = rimAt === undefined ? 1 : interpolate(f, [rimAt, rimAt + 34], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rout = rimUntil === undefined ? 0 : interpolate(f, [rimUntil, rimUntil + 28], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const lvl = rin * (1 - rout);
  const dir = flip ? -1 : 1;
  const sit = pose === 'sit';
  const W0 = sit ? 460 : 260;
  const H0 = sit ? 440 : 620;
  const view = sit ? '0 0 460 440' : '0 0 260 620';
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) scale(${scale})`, opacity, textAlign: 'center'}}>
      <div
        style={{
          width: W0,
          height: H0,
          margin: '0 auto',
          filter: `drop-shadow(${3 * dir}px -1px 0 ${hex2rgba(rim, 0.85 * lvl)}) drop-shadow(${6 * dir}px 0 10px ${hex2rgba(rim, 0.38 * lvl)})`,
        }}
      >
        <svg width={W0} height={H0} viewBox={view} style={{display: 'block', transform: flip ? 'scaleX(-1)' : undefined}}>
          <g fill={INK}>
            {!sit && (
              <>
                {/* ekor imamah */}
                <path d="M66 98 C42 124 44 166 56 196 L74 186 C66 160 70 130 84 110 Z" />
                {/* imamah (serban) berlapis */}
                <path d="M60 94 C54 44 96 14 136 16 C178 18 206 48 200 92 C198 108 184 116 168 118 L90 118 C72 116 61 108 60 94 Z" />
                <path d="M72 38 C92 20 150 12 184 38 C160 30 104 30 72 38 Z" />
                {/* kepala dan janggut (siluet polos, tanpa fitur wajah) */}
                <path d="M86 104 C82 146 100 172 134 174 C168 172 186 146 180 106 Z" />
                <path d="M94 146 C96 200 172 206 180 146 C170 176 104 180 94 146 Z" />
                {/* leher dan jubah */}
                <path d="M110 170 H156 V196 H110 Z" />
                <path d="M112 190 C68 198 44 232 40 296 L20 606 H248 L228 298 C222 232 196 198 154 190 Z" />
                {gesture && <path d="M212 306 C246 288 262 256 252 226 L236 232 C242 254 230 274 204 288 Z" />}
                {/* bahu & lengan jubah */}
                <path d="M40 296 C30 340 34 420 46 470 L74 470 C68 420 70 340 80 300 Z" />
              </>
            )}
            {sit && (
              <>
                <path d="M122 96 C98 120 100 160 112 190 L130 180 C122 154 126 124 140 106 Z" />
                <path d="M112 90 C106 40 148 10 188 12 C230 14 258 44 252 88 C250 104 236 112 220 114 L142 114 C124 112 113 104 112 90 Z" />
                <path d="M124 34 C144 16 202 8 236 34 C212 26 156 26 124 34 Z" />
                <path d="M138 100 C134 142 152 168 186 170 C220 168 238 142 232 102 Z" />
                <path d="M146 142 C148 196 224 200 232 142 C222 172 156 176 146 142 Z" />
                {/* badan duduk bersila */}
                <path d="M166 166 H210 V196 H166 Z" />
                <path d="M170 186 C112 196 80 250 74 320 C50 336 28 372 24 440 H372 C366 388 346 350 316 330 L292 300 C270 236 232 198 208 186 Z" />
                {/* lengan menjulur ke meja */}
                <path d="M236 230 C282 252 330 270 372 272 L376 296 C322 298 270 284 220 262 Z" />
                <path d="M368 262 C384 262 396 272 394 284 C390 296 376 298 366 292 Z" />
                {/* meja rendah */}
                <path d="M300 296 H452 V312 H300 Z" />
                <path d="M318 312 H334 V388 H318 Z" />
                <path d="M420 312 H436 V388 H420 Z" />
              </>
            )}
          </g>
          {!sit && (
            <g fill="none" stroke={rim} strokeLinecap="round" strokeWidth={2} opacity={0.42 * lvl}>
              <path d="M74 70 C100 94 150 98 192 74" />
              <path d="M70 90 C104 112 156 114 196 92" />
            </g>
          )}
          {sit && (
            <g>
              {/* lembar tulis & pena (disorot cahaya lampu) */}
              <path d="M330 288 L430 288 L438 296 L324 296 Z" fill="#f1dfae" opacity={0.78 * Math.max(0.35, lvl)} />
              <path d="M392 288 L420 214" stroke="#d9c58f" strokeWidth={2.4} opacity={0.65 * Math.max(0.35, lvl)} strokeLinecap="round" />
            </g>
          )}
        </svg>
      </div>
      {label && (
        <div style={{...Latin, marginTop: 8 / scale, fontWeight: 700, fontSize: 40, color: C.cream, textShadow: '0 3px 14px #000', lineHeight: 1.1}}>
          {label}
          {sub && <div style={{fontWeight: 500, fontSize: 28, color: C.gold, marginTop: 6}}>{sub}</div>}
        </div>
      )}
    </div>
  );
};
