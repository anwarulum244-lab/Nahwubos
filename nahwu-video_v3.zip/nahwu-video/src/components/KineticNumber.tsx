import React from 'react';
import {interpolate, Easing} from 'remotion';
import {C, Latin, useAnim} from '../lib';

/**
 * Angka kinetik berbasis tipografi: tiap digit adalah kolom odometer (0–9) yang bergulir dan berhenti tepat di angka akhir.
 * Tidak ada angka perantara yang tampil sebagai nilai lain: digit hanya "mendarat" di nilai yang ditentukan.
 * `text` memuat digit dan pemisah (mis. "1.002"); pemisah ditampilkan statis.
 */
export const KineticNumber: React.FC<{
  text: string;
  at: number;
  size?: number;
  color?: string;
  stagger?: number;
  spin?: number;
  glow?: string;
}> = ({text, at, size = 190, color = C.gold, stagger = 5, spin = 22, glow = C.orange}) => {
  const {f} = useAnim();
  const cell = size * 1.06;
  const chars = text.split('');
  let di = 0;
  return (
    <div style={{display: 'inline-flex', alignItems: 'flex-end', ...Latin, fontWeight: 800, fontSize: size, lineHeight: 1, color, filter: `drop-shadow(0 0 22px ${glow}) drop-shadow(0 8px 18px #000)`}}>
      {chars.map((ch, i) => {
        if (!/\d/.test(ch)) {
          const o = interpolate(f, [at + 6, at + 16], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
          return (
            <span key={i} style={{display: 'inline-block', width: size * 0.34, textAlign: 'center', opacity: o, transform: `translateY(${(1 - o) * 16}px)`}}>
              {ch}
            </span>
          );
        }
        const target = Number(ch);
        const k = di++;
        const s = at + k * stagger;
        const p = interpolate(f, [s, s + spin + k * 4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
        // gulir 2 putaran penuh lalu mendarat di digit target
        const pos = (1 - p) * (10 * 2 + 3) + 0; // sisa putaran
        const y = -(target + (pos % 10)) * cell;
        const settle = p >= 1;
        return (
          <span key={i} style={{display: 'inline-block', position: 'relative', width: size * 0.64, height: cell, overflow: 'hidden', opacity: interpolate(f, [s - 2, s + 4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}>
            <span style={{position: 'absolute', left: 0, right: 0, top: 0, textAlign: 'center', transform: `translateY(${settle ? -target * cell : y}px)`, filter: settle ? undefined : `blur(${(1 - p) * 5}px)`}}>
              {Array.from({length: 20}, (_, n) => (
                <span key={n} style={{display: 'block', height: cell, lineHeight: `${cell}px`}}>
                  {n % 10}
                </span>
              ))}
            </span>
          </span>
        );
      })}
    </div>
  );
};
